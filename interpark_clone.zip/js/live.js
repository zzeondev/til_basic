window.addEventListener("load", function () {
  // swiper 만들기 실행
  new Swiper(".sw_live", {
    slidesPerView: 4,
    spaceBetween: 20,
    slidesPerGroup: 4,
  });
});
